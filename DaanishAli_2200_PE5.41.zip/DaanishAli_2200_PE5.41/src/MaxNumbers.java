/*****
 * 
 * @author daanish ali
 * date: 10/24/22
 *
 */

import java.util.Scanner;

public class MaxNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter numbers: ");
		int count = 0;
		int number= input.nextInt();
        int max = number;

		while (number != 0) {
			number = input.nextInt();
			if (number > max) {
				max = number;
				count = 0;
			}
			
			if (number == max)
			count++;
		}
		if (number == 0) {
			System.out.println("No numbers are entered except 0");
		
	}
			System.out.println("The largest number is " + max);
				System.out.println("The occurence count of the largest number is " + count);
		}
		
	}