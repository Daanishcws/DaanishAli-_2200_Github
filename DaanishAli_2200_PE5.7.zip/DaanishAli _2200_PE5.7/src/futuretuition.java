/****
 * 
 * @author daanish ali
 *
 */


public class futuretuition {
	public static void main(String[] args) {
		double tuition = 10000;
		
		for (int i = 0; i < 10; i++) {
			System.out.println("Tuition in year " + (i+1) + ": $" + tuition);
			tuition *= 1.05;
		}
		
		double totalCost = 0;
		for (int i = 0; i < 4; i++) {
			totalCost += tuition;
			tuition *= 1.05;
		}
		
		System.out.println("Total cost of tuition for 4 years, after 10 years: $" + totalCost);
	}
}