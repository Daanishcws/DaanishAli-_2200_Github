/*****
 * 
 * @author daanish ali
 * date:10/12/22
 *
 */
import java.util.Scanner; 

public class Exercise04_05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter the number of sides:");
		int numberofSides = input.nextInt();
		
		System.out.print("Enter the side: ");
		double side = input.nextDouble();
		
		double area = (numberofSides * side * side) /
				(4 * Math.tan(Math.PI / numberofSides));
		
		System.out.println("The area of the polygon is " + area);
		
	}

}
