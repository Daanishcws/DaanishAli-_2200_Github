/******
 * 
 * @author daanish ali
 *
 */
import java.util.Scanner;

public class non_decreasing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner input =  new Scanner(System.in);
     
     System.out.print("Enter three integers ");
     int integer1 = input.nextInt();
     int integer2 = input.nextInt();
     int integer3 = input.nextInt();
    
     int temp; 
     if (integer2 < integer1 || integer3 < integer1)
     {
    	 if (integer2 < integer1)
    	 {
    		 temp = integer1;
    		integer1 = integer2;
    		integer2 = temp;
    	 }
    	 
    	 if (integer3 < integer1)
    	 {
    		 temp = integer1;
    		 integer1 = integer3;
    		 integer3 = temp;
    	 }
     
	}
     if (integer3 < integer2)
     {
    	 temp = integer2;
    	integer2 = integer3;
    	integer3 = temp;
     }
     System.out.println(integer1 + " " + integer2 + " " + integer3);

	}
	
	
}
